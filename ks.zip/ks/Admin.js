function Changepass() {
    var pw = localStorage.getItem("Password");
    if (document.getElementById("curr-psw").value == pw) {
        localStorage.setItem("UserName", "admin");
        localStorage.setItem("Password", document.getElementById("new-psw").value);
        alert("change the password Successfully ");
        document.location.href = "ChangePassword.html";
    } else
        alert("wrong !");
}


//Item
var rIndex,
    table = document.getElementById("milk");

function check() {
    var isEmpty = false,
        Category = document.getElementById("category"),
        name = document.getElementById("name").value,
        price = document.getElementById("price").value,
        available = document.getElementById("available").value;
    if (Category === "") {
        alert("category Cannot be empty!");
        isEmpty = true;
    } else if (name === "") {
        alert("name Cannot be empty!");
        isEmpty = true;
    } else if (price === "") {
        alert("price Cannot be empty!");
        isEmpty = true;
    } else if (available == "") {
        alert("avaiability cannot be empty!");
    }
    return isEmpty;

}

function Addclick() {
    if (!check()) {
        var newRow = table.insertRow(table.length),
            cell1 = newRow.insertCell(0),
            cell2 = newRow.insertCell(1),
            cell3 = newRow.insertCell(2),
            cell4 = newRow.insertCell(3),
            category = document.getElementById("category").value,
            name = document.getElementById("name").value,
            price = document.getElementById("price").value,
            available = document.getElementById("available").value;
        cell1.innerHTML = category;
        cell2.innerHTML = name;
        cell3.innerHTML = price;
        cell4.innerHTML = available;
        SelectRow();

        category = document.getElementById("category").value = "";
        name = document.getElementById("name").value = "";
        price = document.getElementById("price").value = "";
        available = document.getElementById("available").value = "";
    }
}














function Delclick() {
    table.deleteRow(-1);
    category = document.getElementById("category").value = "";
    n = document.getElementById("name").value = "";
    price = document.getElementById("price").value = "";
    available = document.getElementById("available").value = "";

}

function SelectRow() {

    for (var i = 1; i < table.rows.length; i++) {
        table.rows[i].onclick = function() {
            rIndex = this.rowIndex;
            document.getElementById("category").value = this.cells[0].innerHTML;
            document.getElementById("name").value = this.cells[1].innerHTML;
            document.getElementById("price").value = this.cells[2].innerHTML;
            document.getElementById("available").value = this.cells[3].innerHTML;
        };

    }
}
SelectRow();

function Ediclick() {
    if (!check()) {
        var category = document.getElementById("category").value,
            name = document.getElementById("name").value,
            price = document.getElementById("price").value,
            available = document.getElementById("available").value;

        table.rows[rIndex].cells[0].innerHTML = category;
        table.rows[rIndex].cells[1].innerHTML = name;
        table.rows[rIndex].cells[2].innerHTML = price;
        table.rows[rIndex].cells[3].innerHTML = available;
    }
}