var cartinformation = 0;

function stickyMenu() {
    var sticky = document.getElementById('sticky');
    if (window.pageYOffset > 220) {
        sticky.classList.add('sticky');
    } else {
        sticky.classList.remove('sticky');
    }
}

window.onscroll = function() {
    stickyMenu();
}

function searchfunc() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    a = document.getElementsByClassName("dropdown-item");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        console.log(1);
        if (txtValue.toUpperCase().indexOf(filter) > -1 && filter.length != 0) {
            a[i].style.display = "block";
        } else {
            a[i].style.display = "none";
        }
    }
}


function AddtoCart(milk) {

    var grams = 250;;
    var price = 0;

    if (cartinformation == "")
        cartinformation = 1;
    else
        cartinformation = 1 + cartinformation;


    if (milk == "tonnedmilk") {
        var e = document.getElementById("selecttonnedmilk");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;

    } else if ((milk == "fullcreammilk")) {
        var e = document.getElementById("selectfullcreammilk");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;
    } else if ((milk == "skimmedmilk")) {
        var e = document.getElementById("selectskimmedmilk");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;
    } else if ((milk == "bread")) {
        var e = document.getElementById("selectbread");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;
    } else if ((milk == "butter")) {
        var e = document.getElementById("selectbutter");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 49;
    } else if ((milk == "cheese")) {
        var e = document.getElementById("selectcheese");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 120;
    } else if ((milk == "bun")) {
        var e = document.getElementById("selectbun");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 40;
    } else if ((milk == "egg")) {
        var e = document.getElementById("selectegg");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 60;
    } else if ((milk == "mangojuice")) {
        var e = document.getElementById("selectmango");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;
    } else if ((milk == "strawberry")) {
        var e = document.getElementById("selectstrawberry");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30
    } else if ((milk == "mixedjuice")) {
        var e = document.getElementById("selectmixed");
        grams = e.options[e.selectedIndex].text;
        price = '₹' + e.options[e.selectedIndex].value * 30;
    }


    var newdata = "";
    var milkdetails = milk + "~" + grams + "~" + price;
    var olddata = sessionStorage.getItem("Cartdetails");
    if (olddata == null)
        newdata = milkdetails;
    else
        newdata = olddata + ";" + milkdetails;

    sessionStorage.setItem("Cartdetails", newdata);

    document.getElementById('lblCartDetails').innerText = cartinformation;
}